# -*- coding: utf-8 -*-
from flask import Flask, render_template, request

app = Flask(__name__) 


pos_equipos = {"River" : "Campeón", 
               "Boca": "Sub Campeón",
               "Gremio": "Semi finalista",
               "Palmeiras": "Semi finalista"}

@app.route("/")
def index():
    return render_template ("index.html", contenido="mundo")


@app.route("/equipos")
def equipos():
    return render_template("equipos.html", contenido=pos_equipos)

@app.route("/equipos")
def equipos2():
    return render_template("equipos.html", contenido=pos_equipos)


@app.route("/agregar", methods=["POST"])
def agregar():
    equipo = request.form.get("equipo")
    posicion = request.form.get("posicion")
    pos_equipos[equipo] = posicion
    return render_template("equipos.html", contenido=pos_equipos)

