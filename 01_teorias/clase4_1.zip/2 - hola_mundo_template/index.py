# -*- coding: utf-8 -*-
from flask import Flask, render_template

app = Flask(__name__) 


@app.route("/")
def hola_mundo():
    return render_template ("index.html")


@app.route("/personas")
def personas():
    contenido = "Hola personas!"
    return render_template("index1.html", contenido=contenido)

@app.route("/personas/<string:nombre>")
def persona(nombre):
    nombre = nombre.capitalize()
    contenido = f"Hola {nombre}"
    return render_template("index1.html", contenido=contenido)

