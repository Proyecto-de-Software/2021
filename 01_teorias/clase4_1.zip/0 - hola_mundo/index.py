# -*- coding: utf-8 -*-
from flask import Flask

app = Flask(__name__) 


@app.route("/")
def index():
    return "Hola mundo" + 2


@app.route("/personas")
def personas():
    return "personas"

@app.route("/personas/<string:nombre>")
def persona(nombre):
    nombre = nombre.capitalize()
    return f"Hola {nombre}"

