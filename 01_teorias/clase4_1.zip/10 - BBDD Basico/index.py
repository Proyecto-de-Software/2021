# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, session
from flask_session import Session
import pymysql



app = Flask(__name__) 

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"

Session(app)

@app.route("/")
def index():
    return render_template ("index.html")


@app.route("/equipos")
def equipos():
    db = connection()
    
    with db.cursor() as cursor:
        res = cursor.execute("select * from equipos")
        
    if res:
        equipos = cursor.fetchall()
    else:
        equipos = []

    return render_template("equipos.html", contenido=equipos)

@app.route("/agregar", methods=["POST"])
def agregar():
    equipo = request.form.get("equipo")
    posicion = request.form.get("posicion")

    db = connection()
    
    with db.cursor() as cursor:
        res = cursor.execute("insert into equipos (descripcion, posicion) values (%s, %s)",
                             (equipo, posicion))
        db.commit()

    with db.cursor() as cursor:
        res = cursor.execute("select * from equipos")
        
    if res:
        equipos = cursor.fetchall()
    else:
        equipos = []


    return render_template("equipos.html", contenido=equipos)

def connection():
    db_conn = pymysql.connect(
        host="proyecto2021",
        user="proyecto2021",
        password="proyecto2021",
        db="proyecto2021",
        cursorclass=pymysql.cursors.DictCursor,
    )
    return db_conn




