# -*- coding: utf-8 -*-
from flask import Flask

app = Flask(__name__) 


@app.route("/")
def hola_mundo():
    mensaje = '<!DOCTYPE html>'
    mensaje +=  '<html lang="es"> '
    mensaje +=  '<head>'
    mensaje += '</head>'
    mensaje += '<body>'
    mensaje += 'Hola mundo!'
    mensaje += '</body>'
    mensaje += '</html>'
    return mensaje


@app.route("/personas")
def personas():
    mensaje = '<!DOCTYPE html>'
    mensaje +=  '<html lang="es"> '
    mensaje +=  '<head>'
    mensaje += '</head>'
    mensaje += '<body>'
    mensaje += 'Hola personas!'
    mensaje += '</body>'
    mensaje += '</html>'
    return mensaje

@app.route("/personas/<string:nombre>")
def persona(nombre):
    nombre = nombre.capitalize()
    mensaje = '<!DOCTYPE html>'
    mensaje +=  '<html lang="es"> '
    mensaje +=  '<head>'
    mensaje += '</head>'
    mensaje += '<body>'
    mensaje += f"<h1>Hola {nombre}<h1>"
    mensaje += '</body>'
    mensaje += '</html>'
    return mensaje


