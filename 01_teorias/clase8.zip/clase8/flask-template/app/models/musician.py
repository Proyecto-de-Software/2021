class Musician(object):

    db = None

    @classmethod
    def all(cls, conn):
        sql = 'SELECT * FROM musicians'
        cursor = conn.cursor()
        cursor.execute(sql)

        return cursor.fetchall()


    @classmethod
    def find_by_name(cls,  conn, name):
        sql = """
            SELECT * FROM musicians AS m
            WHERE m.name like %s
        """

        cursor = conn.cursor()
        cursor.execute(sql, (name+"%"))

        return cursor.fetchone()
