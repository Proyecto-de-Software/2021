from flask import request, jsonify, render_template
from app.db import connection
from app.models.musician import Musician


def get_all():

    conn = connection()
    musician = Musician.all(conn)
    
    return jsonify(musician=musician)


def find_by_name():

    params = request.args
    conn = connection()
    musician = Musician.find_by_name(conn, params['name'])

    return jsonify(musician=musician)

def find_xss():
    params = request.args  
    if 'buscar' not in params:
        conn = connection()
        musician = Musician.find_by_name(conn, 'xss')
        return render_template('xss.html', musician=musician)
    else:
        return render_template('xss.html', buscar=params['buscar'])
