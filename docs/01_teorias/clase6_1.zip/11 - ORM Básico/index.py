# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, session
from flask_session import Session
from flask_sqlalchemy import SQLAlchemy
import os
from equipos import *




app = Flask(__name__) 

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("BBDD")
db = SQLAlchemy(app)
Session(app)

@app.route("/")
def index():
    return render_template ("index.html")


@app.route("/equipos")
def equipos():

    equipos = Equipo.query.all()
    print (equipos)
    return render_template("equipos.html", contenido=equipos)

@app.route("/agregar", methods=["POST"])
def agregar():
    equipo = request.form.get("equipo")
    posicion = request.form.get("posicion")
    
    nuevo = Equipo(descripcion=equipo, posicion=posicion)
    db.session.add(nuevo)
    db.session.commit()
    
    equipos = Equipo.query.all()
    print (equipos)
    
    return render_template("equipos.html", contenido=equipos)




