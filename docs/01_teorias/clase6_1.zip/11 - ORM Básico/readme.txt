Las variables de entorno que tengo en este ejemplo son:

export FLASK_APP=index.py
export FLASK_ENV=development
export BBDD=mysql+pymysql://proyecto2021:proyecto2021@localhost/proyecto2021

Acá deberían reemplazar los proyecto2020:
 - El primero es el usuario.
 - El segundo la password
 - El tercero es es esquema de la base de datos.
 
 Dentro de la carpeta BBDD del ejemplo 10 tienen el modelo para mysql workbench y un dump.


En el archivo ejemploTeoria.txt estan los paquetes que tengo en mi entorno virtual. Lo dejo así para que no importen todo de una pero que les sirva de referencia.


