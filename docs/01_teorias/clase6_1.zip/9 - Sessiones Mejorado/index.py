# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, session
from flask_session import Session

app = Flask(__name__) 

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"

Session(app)

@app.route("/")
def index():
    
    if session.get("pos_equipos") is None:
        session["pos_equipos"] = { "River" : "Campeón", 
                                   "Boca": "Sub Campeón",
                                   "Gremio": "Semi finalista",
                                   "Palmeiras": "Semi finalista"}

    return render_template ("index.html")


@app.route("/equipos")
def equipos():
    return render_template("equipos.html", contenido=session["pos_equipos"])

@app.route("/agregar", methods=["POST"])
def agregar():
    equipo = request.form.get("equipo")
    posicion = request.form.get("posicion")
    session["pos_equipos"][equipo] = posicion
    return render_template("equipos.html", contenido=session["pos_equipos"])

