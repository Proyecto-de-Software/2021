<template>
  <div class="ruta2">
    <h1>Ruta 2</h1>
  </div>
</template>
