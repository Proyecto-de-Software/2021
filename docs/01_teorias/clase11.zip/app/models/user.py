class User(object):

    def __init__(self, id_, name, email, profile_pic):
        self.id = id_
        self.name = name
        self.email = email
        self.profile_pic = profile_pic
        self.is_active = True
        
    @staticmethod
    def get(user_id):
        ######## retornar valores del user
        
        return ("id", "name", "email", "profile_pic")

    @staticmethod
    def create(id_, name, email, profile_pic):
        #### Creación en la bbdd
        pass
        
    @classmethod
    def all(cls, conn):
        sql = "SELECT * FROM users"
        cursor = conn.cursor()
        cursor.execute(sql)

        return cursor.fetchall()

    @classmethod
    def create(cls, conn, data):
        sql = """
            INSERT INTO users (email, password, first_name, last_name)
            VALUES (%s, %s, %s, %s)
        """

        cursor = conn.cursor()
        cursor.execute(sql, list(data.values()))
        conn.commit()

        return True

    @classmethod
    def find_by_email_and_pass(cls, conn, email, password):
        sql = """
            SELECT * FROM users AS u
            WHERE u.email = %s AND u.password = %s
        """

        cursor = conn.cursor()
        cursor.execute(sql, (email, password))

        return cursor.fetchone()
